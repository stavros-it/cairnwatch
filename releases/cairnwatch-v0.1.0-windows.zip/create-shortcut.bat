@echo off
setlocal
set "EXE=%~dp0cairnwatch.exe"
if not exist "%EXE%" (
  echo cairnwatch.exe not found next to this script.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=[Environment]::GetFolderPath('Desktop');" ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Cairnwatch.lnk'));" ^
  "$s.TargetPath='%EXE%';" ^
  "$s.WorkingDirectory='%~dp0';" ^
  "$s.IconLocation='%EXE%,0';" ^
  "$s.Save()"
if errorlevel 1 (
  echo Failed to create shortcut.
) else (
  echo Shortcut created on Desktop.
)
pause
